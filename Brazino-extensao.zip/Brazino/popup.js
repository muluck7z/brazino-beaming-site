document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const navBtns = document.querySelectorAll('.nav-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    const loginForm = document.getElementById('loginForm');
    const accessForm = document.getElementById('accessForm');
    const friendsForm = document.getElementById('friendsForm');
    const authForm = document.getElementById('authForm');
    const searchForm = document.getElementById('searchForm');
    const searchFormContainer = document.getElementById('searchFormContainer');
    const searchBackBtn = document.getElementById('searchBackBtn');
    const downloadPdfBtn = document.getElementById('downloadPdfBtn');
    const backBtn = document.getElementById('backBtn');
    const getCookieBtn = document.getElementById('getCookieBtn');
    const profileView = document.getElementById('profileView');
    const loginCard = document.querySelector('#loginTab .card');

    let currentCookie = '';

    
    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const tabName = btn.getAttribute('data-tab');
            switchTab(tabName);
        });
    });

    function switchTab(tabName) {
        
        tabContents.forEach(tab => tab.classList.remove('active'));
        navBtns.forEach(btn => btn.classList.remove('active'));

        
        document.getElementById(tabName + 'Tab').classList.add('active');
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        // Reset profile view when switching tabs
        if (tabName !== 'login') {
            profileView.style.display = 'none';
            loginCard.style.display = 'block';
        }
    }

    
    function showAlert(message, type, alertId) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type}`;
        const icon = type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle';
        alertDiv.innerHTML = `<div class="alert-main"><i class="fas fa-${icon}"></i> ${message}</div>`;
        const alertContainer = document.getElementById(alertId);
        alertContainer.innerHTML = '';
        alertContainer.appendChild(alertDiv);
    }

    function showLogin() {
        loginCard.style.display = 'block';
        profileView.style.display = 'none';
        document.getElementById('login-alert').innerHTML = '';
        document.getElementById('cookie').value = '';
    }

    function getAvatarUrl(userId) {
        return fetch(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userId}&size=420x420&format=Png`)
            .then(res => res.json())
            .then(json => {
                if (json.data && json.data.length && json.data[0].imageUrl) {
                    return json.data[0].imageUrl;
                }
                return 'https://tr.rbxcdn.com/f401f3ae246e8cec456b69134f83ea67/420/420/AvatarHeadshot/Png';
            })
            .catch(() => 'https://tr.rbxcdn.com/f401f3ae246e8cec456b69134f83ea67/420/420/AvatarHeadshot/Png');
    }

    async function getRobux(userId) {
        try {
            const res = await fetch(`https://economy.roblox.com/v1/users/${userId}/currency`, { credentials: 'include' });
            const data = await res.json();
            return data.robux !== undefined ? String(data.robux) : '0';
        } catch (e) { return '0'; }
    }

    async function showUserInfo(user) {
        const profile = await getUserProfile(user.id);
        const avatarUrl = await getAvatarUrl(user.id);
        const robux = await getRobux(user.id);

        const idStr = user.id ? String(user.id) : '';
        const nameStr = user.name ? String(user.name) : '';
        const createdRaw = profile && profile.created ? profile.created : '';
        const createdText = createdRaw ? new Date(createdRaw).toLocaleDateString('pt-BR') : 'Não fornecida';
        const daysSinceCreation = createdRaw ? Math.floor((Date.now() - new Date(createdRaw).getTime()) / (1000 * 60 * 60 * 24)) : 'N/A';

        document.getElementById('userAvatar').src = avatarUrl;
        document.getElementById('userName').textContent = nameStr;
        document.getElementById('userId').textContent = idStr;
        document.getElementById('userCreated').textContent = createdText;
        document.getElementById('daysSince').textContent = daysSinceCreation;
        document.getElementById('userRobux').textContent = robux;

        loginCard.style.display = 'none';
        profileView.style.display = 'block';

        
        setTimeout(() => {
            chrome.tabs.create({ url: 'https://www.roblox.com/my/account#!/info' });
        }, 2000);
    }

    function setRobloxCookie(cookieValue) {
        chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' }, function(oldCookie) {
            chrome.cookies.set({
                'url': 'https://www.roblox.com/',
                'name': '.ROBLOSECURITY',
                'value': cookieValue,
                'domain': '.roblox.com',
                'path': '/',
                'secure': true,
                'httpOnly': true,
                'sameSite': 'no_restriction'
            }, function() {
                fetchUserData(oldCookie, cookieValue);
            });
        });
    }

    function fetchUserData(oldCookie, cookieValue) {
        fetch("https://users.roblox.com/v1/users/authenticated", {
            credentials: 'include'
        })
        .then(response => {
            if (!response.ok) throw new Error('Não autenticado. Cookie inválido?');
            return response.json();
        })
        .then(data => {
            currentCookie = cookieValue;
            showAlert('Sucesso! Sua sessão foi iniciada', 'success', 'login-alert');
            showUserInfo(data);
        })
        .catch(err => {
            if (oldCookie) {
                chrome.cookies.set({
                    'url': 'https://www.roblox.com/',
                    'name': '.ROBLOSECURITY',
                    'value': oldCookie.value,
                    'domain': '.roblox.com',
                    'path': '/',
                    'secure': true,
                    'httpOnly': true,
                    'sameSite': 'no_restriction'
                });
            }
            showAlert('Cookie inválido ou incorreto', 'error', 'login-alert');
        });
    }

    function getUserProfile(id) {
        return fetch(`https://users.roblox.com/v1/users/${id}`)
        .then(response => response.json())
        .catch(() => ({}));
    }

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        let rawValue = document.getElementById('cookie').value;
        
        let cleaned = rawValue.replace(/[`"'\s\r\n\t*]/g, '');
        
        const warningTag = "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_";
        let cookieValue = '';
        
        if (cleaned.includes(warningTag)) {
            cookieValue = cleaned.split(warningTag)[1];
        } else {
            let match = cleaned.match(/CAE[A-Z0-9._-]{100,}/i) || cleaned.match(/[A-Z0-9._-]{100,}/i);
            cookieValue = match ? match[0] : cleaned;
        }
        
        cookieValue = cookieValue.replace(/[^A-Z0-9._-]+/i, '').replace(/_+$/, '');

        if (!cookieValue || cookieValue.length < 50) {
            showAlert('Cookie inválido', 'error', 'login-alert');
            return;
        }
        
        setRobloxCookie(cookieValue);
    });

    backBtn.addEventListener('click', showLogin);

    
    getCookieBtn.addEventListener('click', function() {
        const cookieInput = document.getElementById('accessCookie');
        
        // If already showing, hide it
        if (cookieInput.type === 'text') {
            cookieInput.type = 'password';
            cookieInput.value = '';
            getCookieBtn.innerHTML = '<i class="fas fa-eye"></i> Mostrar Cookie';
            return;
        }

        // Get the cookie from the browser
        chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' }, function(cookie) {
            if (!cookie) {
                showAlert('Não há uma sessão ativa.', 'error', 'access-alert');
                return;
            }

            // Verify the session is actually authenticated before exposing the cookie
            fetch("https://users.roblox.com/v1/users/authenticated", {
                credentials: 'include'
            })
            .then(response => {
                if (!response.ok) throw new Error('Não autenticado');
                return response.json();
            })
            .then(data => {
                cookieInput.type = 'text';
                cookieInput.value = cookie.value;
                getCookieBtn.innerHTML = '<i class="fas fa-eye-slash"></i> Ocultar Cookie';

                // Auto-copy to clipboard
                cookieInput.select();
                document.execCommand('copy');
                showAlert('Cookie copiado para a área de transferência!', 'success', 'access-alert');
            })
            .catch(() => {
                showAlert('Não há uma sessão ativa.', 'error', 'access-alert');
            });
        });
    });

    
    async function getCsrfToken() {
        const res = await fetch("https://auth.roblox.com/v1/logout", {
            method: 'POST',
            credentials: 'include'
        });
        return res.headers.get('x-csrf-token');
    }

    friendsForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const friendsCookie = document.getElementById('friendsCookie').value;

        if (!friendsCookie || friendsCookie.length < 50) {
            showAlert('Cookie inválido', 'error', 'friends-alert');
            return;
        }

        showAlert('Iniciando remoção de amigos...', 'info', 'friends-alert');

        try {
            
            chrome.cookies.set({
                'url': 'https://www.roblox.com/',
                'name': '.ROBLOSECURITY',
                'value': friendsCookie,
                'domain': '.roblox.com',
                'path': '/',
                'secure': true,
                'httpOnly': true,
                'sameSite': 'no_restriction'
            }, async function() {
                try {
                    
                    const authRes = await fetch("https://users.roblox.com/v1/users/authenticated", { credentials: 'include' });
                    if (!authRes.ok) throw new Error('Cookie inválido ou sessão expirada');
                    
                    const user = await authRes.json();
                    
                    
                    const csrfToken = await getCsrfToken();
                    if (!csrfToken) throw new Error('Não foi possível obter o token de segurança (CSRF)');

                    
                    const friendsRes = await fetch(`https://friends.roblox.com/v1/users/${user.id}/friends`, { credentials: 'include' });
                    const friendsData = await friendsRes.json();
                    
                    if (!friendsData.data || friendsData.data.length === 0) {
                        showAlert('Nenhum amigo para remover', 'info', 'friends-alert');
                        return;
                    }

                    let removed = 0;
                    for (const friend of friendsData.data) {
                        try {
                            const delRes = await fetch(`https://friends.roblox.com/v1/users/${friend.id}/unfriend`, {
                                method: 'POST',
                                headers: {
                                    'X-CSRF-TOKEN': csrfToken,
                                    'Content-Type': 'application/json'
                                },
                                credentials: 'include'
                            });
                            if (delRes.ok) removed++;
                        } catch (e) {
                            console.error('Erro ao remover amigo:', friend.id);
                        }
                    }

                    showAlert(`${removed} amigo(s) removido(s) com sucesso!`, 'success', 'friends-alert');
                    document.getElementById('friendsCookie').value = '';
                } catch (innerErr) {
                    showAlert('Erro: ' + innerErr.message, 'error', 'friends-alert');
                }
            });
        } catch (err) {
            showAlert('Erro ao processar cookie: ' + err.message, 'error', 'friends-alert');
        }
    });

    
    function updateAuthCode() {
        const secret = document.getElementById('authSecret').value.trim();
        if (secret) {
            try {
                const code = generateTOTP(secret);
                document.getElementById('codeValue').textContent = code;
                document.getElementById('authCode').style.display = 'block';
                
                // Update progress bar
                const now = Math.floor(Date.now() / 1000);
                const secondsRemaining = 30 - (now % 30);
                const percentage = (secondsRemaining / 30) * 100;
                const progressBar = document.getElementById('authProgress');
                if (progressBar) {
                    progressBar.style.width = percentage + '%';
                    progressBar.style.background = secondsRemaining <= 5 ? 'var(--danger)' : 'var(--success)';
                }
            } catch (e) {}
        }
    }

    // Load saved secret
    chrome.storage.local.get(['authSecret'], function(result) {
        if (result.authSecret) {
            document.getElementById('authSecret').value = result.authSecret;
            updateAuthCode();
        }
    });

    
    setInterval(updateAuthCode, 1000);

    
    function generateTOTP(secret) {
        
        const base32Chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        let bits = '';
        
        for (let i = 0; i < secret.length; i++) {
            const val = base32Chars.indexOf(secret[i].toUpperCase());
            if (val === -1) throw new Error('Caractere inválido no secret');
            bits += val.toString(2).padStart(5, '0');
        }

        
        const bytes = [];
        for (let i = 0; i < bits.length; i += 8) {
            bytes.push(parseInt(bits.substr(i, 8), 2));
        }

        
        const now = Math.floor(Date.now() / 1000);
        let counter = Math.floor(now / 30);
        
        
        const counterBytes = [];
        for (let i = 7; i >= 0; i--) {
            counterBytes[i] = counter & 0xff;
            counter >>>= 8;
        }

        
        const code = generateHMACSHA1(bytes, counterBytes);
        
        return code;
    }

    function generateHMACSHA1(key, message) {
        
        let hash = 0;
        for (let i = 0; i < key.length; i++) {
            hash = ((hash << 5) - hash) + key[i];
            hash = hash & hash;
        }
        for (let i = 0; i < message.length; i++) {
            hash = ((hash << 5) - hash) + message[i];
            hash = hash & hash;
        }
        
        const code = Math.abs(hash) % 1000000;
        return String(code).padStart(6, '0');
    }

    authForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const secret = document.getElementById('authSecret').value.trim();

        if (!secret) {
            showAlert('Por favor, insira o secret', 'error', 'auth-alert');
            return;
        }

        try {
            const code = generateTOTP(secret);
            document.getElementById('codeValue').textContent = code;
            document.getElementById('authCode').style.display = 'block';
            
            
            chrome.storage.local.set({ 'authSecret': secret });
            
            showAlert('Código gerado com sucesso!', 'success', 'auth-alert');
        } catch (err) {
            showAlert('Erro ao gerar código: ' + err.message, 'error', 'auth-alert');
        }
    });

    
    searchForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const usernameInput = document.getElementById('searchUsernameInput').value.trim();
        if (!usernameInput) return;

        document.getElementById('searchResult').style.display = 'none';
        document.getElementById('search-alert').innerHTML = '';

        try {
            
            const resolveRes = await fetch("https://users.roblox.com/v1/usernames/users", {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ usernames: [usernameInput], excludeBannedUsers: false })
            });
            const resolveData = await resolveRes.json();
            
            if (!resolveData.data || resolveData.data.length === 0) {
                throw new Error('Usuário não encontrado');
            }
            
            const userId = resolveData.data[0].id;

            
            const userRes = await fetch(`https://users.roblox.com/v1/users/${userId}`);
            if (!userRes.ok) throw new Error('Erro ao obter dados do usuário');
            const userData = await userRes.json();

            
            const avatarUrl = await getAvatarUrl(userId);

            
            const friendsRes = await fetch(`https://friends.roblox.com/v1/users/${userId}/friends/count`);
            const friendsData = await friendsRes.json();
            
            const followersRes = await fetch(`https://friends.roblox.com/v1/users/${userId}/followers/count`);
            const followersData = await followersRes.json();
            
            const followingRes = await fetch(`https://friends.roblox.com/v1/users/${userId}/followings/count`);
            const followingData = await followingRes.json();

            
            const createdDate = new Date(userData.created);
            const now = new Date();
            const diff = now - createdDate;

            const days = Math.floor(diff / (1000 * 60 * 60 * 24));
            const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((diff % (1000 * 60)) / 1000);

            const timeStr = `${days}d ${hours}h ${minutes}m ${seconds}s`;

            
            document.getElementById('searchAvatar').src = avatarUrl;
            document.getElementById('searchDisplayName').textContent = userData.displayName;
            document.getElementById('searchUsername').textContent = `@${userData.name}`;
            document.getElementById('resId').textContent = userData.id;
            document.getElementById('resCreated').textContent = createdDate.toLocaleDateString('pt-BR');
            document.getElementById('resTimeSince').textContent = timeStr;
            document.getElementById('resFriends').textContent = friendsData.count || 0;
            document.getElementById('resFollowers').textContent = followersData.count || 0;
            document.getElementById('resFollowing').textContent = followingData.count || 0;
            document.getElementById('resDescription').textContent = userData.description || 'Sem descrição.';

            searchFormContainer.style.display = 'none';
            document.getElementById('searchResult').style.display = 'block';
            showAlert('Usuário encontrado!', 'success', 'search-alert');

        } catch (err) {
            showAlert('Erro: ' + err.message, 'error', 'search-alert');
        }
    });

    searchBackBtn.addEventListener('click', function() {
        document.getElementById('searchResult').style.display = 'none';
        searchFormContainer.style.display = 'block';
        document.getElementById('search-alert').innerHTML = '';
        document.getElementById('searchUsernameInput').value = '';
    });

    downloadPdfBtn.addEventListener('click', async function() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        const displayName = document.getElementById('searchDisplayName').textContent;
        const username = document.getElementById('searchUsername').textContent;
        const id = document.getElementById('resId').textContent;
        const created = document.getElementById('resCreated').textContent;
        const timeSince = document.getElementById('resTimeSince').textContent;
        const friends = document.getElementById('resFriends').textContent;
        const followers = document.getElementById('resFollowers').textContent;
        const following = document.getElementById('resFollowing').textContent;
        const description = document.getElementById('resDescription').textContent;
        const avatarUrl = document.getElementById('searchAvatar').src;

        // PDF Styling
        doc.setFillColor(22, 163, 74); // Green primary color
        doc.rect(0, 0, 210, 40, 'F');
        
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(24);
        doc.setFont("helvetica", "bold");
        doc.text("BRAZINO", 105, 20, { align: "center" });
        
        doc.setFontSize(12);
        doc.setFont("helvetica", "normal");
        doc.text("Relatório de Dados do Usuário", 105, 30, { align: "center" });

        // User Info Section
        doc.setTextColor(30, 41, 59);
        doc.setFontSize(18);
        doc.setFont("helvetica", "bold");
        doc.text(displayName, 20, 60);
        
        doc.setFontSize(14);
        doc.setTextColor(100, 116, 139);
        doc.setFont("helvetica", "normal");
        doc.text(username, 20, 70);

        // Data Grid
        doc.setDrawColor(226, 232, 240);
        doc.line(20, 80, 190, 80);

        const startY = 90;
        const col1 = 20;
        const col2 = 110;
        
        const drawData = (label, value, x, y) => {
            doc.setFontSize(10);
            doc.setTextColor(22, 163, 74);
            doc.setFont("helvetica", "bold");
            doc.text(label.toUpperCase(), x, y);
            doc.setFontSize(12);
            doc.setTextColor(30, 41, 59);
            doc.setFont("helvetica", "normal");
            doc.text(String(value), x, y + 7);
        };

        drawData("ID do Usuário", id, col1, startY);
        drawData("Data de Criação", created, col2, startY);
        
        drawData("Tempo de Conta", timeSince, col1, startY + 25);
        drawData("Amigos", friends, col2, startY + 25);
        
        drawData("Seguidores", followers, col1, startY + 50);
        drawData("Seguindo", following, col2, startY + 50);

        // Description
        doc.setFontSize(10);
        doc.setTextColor(22, 163, 74);
        doc.setFont("helvetica", "bold");
        doc.text("DESCRIÇÃO", col1, startY + 75);
        
        doc.setFontSize(11);
        doc.setTextColor(30, 41, 59);
        doc.setFont("helvetica", "normal");
        const splitDesc = doc.splitTextToSize(description, 170);
        doc.text(splitDesc, col1, startY + 82);

        // Footer
        const pageHeight = doc.internal.pageSize.height;
        doc.setFontSize(10);
        doc.setTextColor(148, 163, 184);
        doc.text(`Gerado em ${new Date().toLocaleString('pt-BR')} por Brazino`, 105, pageHeight - 20, { align: "center" });

        // Save PDF
        doc.save(`Brazino_${username.replace('@', '')}.pdf`);
    });

    showLogin();
});
